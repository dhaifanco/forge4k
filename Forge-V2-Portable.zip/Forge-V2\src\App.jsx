import React from 'react';
import { HashRouter, Routes, Route, NavLink } from 'react-router-dom';
import Optimizer from './pages/Optimizer.jsx';
import Analyzer from './pages/Analyzer.jsx';
import History from './pages/History.jsx';
import Settings from './pages/Settings.jsx';
import { api } from './api';
import { Dot } from './ui.jsx';

export default function App() {
  const [health, setHealth] = React.useState(null);
  React.useEffect(() => {
    api.health().then(setHealth).catch(() => setHealth({ ffmpegReady: false, ok: false }));
  }, []);

  return (
    <HashRouter>
      <div className="shell">
        <aside className="sidebar">
          <div className="logo">
            <div className="logo-mark">▞</div>
            <div>
              <div className="logo-name">FORGE</div>
              <div className="logo-sub">local video optimizer</div>
            </div>
          </div>
          <nav>
            <NavLink to="/" end><span className="nav-ico">◈</span>Optimizer</NavLink>
            <NavLink to="/analyzer"><span className="nav-ico">◌</span>Video Analyzer</NavLink>
            <NavLink to="/history"><span className="nav-ico">≡</span>History</NavLink>
            <NavLink to="/settings"><span className="nav-ico">⚙</span>Settings</NavLink>
          </nav>
          <div className="sidebar-foot">
            <div className="status-chip">
              <Dot ok={!!(health && health.ffmpegReady)} warn={health && !health.ok} />
              <span>{!health ? 'checking…' : health.ffmpegReady ? 'FFmpeg ready' : 'FFmpeg missing'}</span>
            </div>
            <div className="status-sub">100% local · no uploads</div>
          </div>
        </aside>
        <main className="main">
          <Routes>
            <Route path="/" element={<Optimizer />} />
            <Route path="/analyzer" element={<Analyzer />} />
            <Route path="/history" element={<History />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>
      </div>
    </HashRouter>
  );
}
