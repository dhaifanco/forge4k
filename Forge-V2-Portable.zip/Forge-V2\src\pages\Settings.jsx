import React from 'react';
import { api } from '../api';
import { Card, ErrorBar, Badge, Spec } from '../ui';

export default function Settings() {
  const [settings, setSettings] = React.useState(null);
  const [health, setHealth] = React.useState(null);
  const [busy, setBusy] = React.useState(false);
  const [msg, setMsg] = React.useState(null);
  const [error, setError] = React.useState(null);

  function load() {
    api.settings().then(setSettings).catch((e) => setError(e.message));
    api.health().then(setHealth).catch(() => {});
  }
  React.useEffect(load, []);

  async function setupFfmpeg() {
    setBusy(true); setError(null); setMsg('Downloading FFmpeg (gyan.dev essentials build)… this can take a minute.');
    try {
      const r = await api.setupFfmpeg();
      setMsg('FFmpeg installed to ' + r.binDir);
      load();
    } catch (e) { setError(e.message); setMsg(null); }
    setBusy(false);
  }

  async function save(patch) {
    setError(null);
    try {
      const r = await api.saveSettings(patch);
      setSettings(r.settings);
      const h = await api.health();
      setHealth(h);
      setMsg('Saved.');
      setTimeout(() => setMsg(null), 2000);
    } catch (e) { setError(e.message); }
  }

  if (!settings) return <div className="page"><ErrorBar>{error}</ErrorBar><div className="card center-card"><div className="spinner" /> Loading…</div></div>;

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>Settings</h1>
          <p className="page-sub">Everything stays on this PC. Nothing is uploaded, ever.</p>
        </div>
      </header>

      <ErrorBar>{error}</ErrorBar>
      {msg && <div className="okbar">{msg}</div>}

      <Card title="FFmpeg">
        <div className={'ff-status ' + (health && health.ffmpegReady ? 'ok' : 'bad')}>
          {health && health.ffmpegReady
            ? <>✓ Ready — <span className="mono small">{health.ffmpeg}</span></>
            : <>✕ FFmpeg not detected. Install automatically, or install manually and set the path below.</>}
        </div>
        <div className="btn-row">
          <button className="btn primary" disabled={busy} onClick={setupFfmpeg}>{busy ? 'Installing…' : 'Auto-install FFmpeg (Windows)'}</button>
          <button className="btn" disabled={busy} onClick={async () => { const r = await api.detect(); setMsg(r.ok ? 'FFmpeg detected.' : 'Still not found.'); load(); }}>Re-detect</button>
        </div>
        <p className="muted small">
          Auto-install downloads the essentials build from gyan.dev into <span className="mono">%LOCALAPPDATA%\ffmpeg</span> and registers it — no admin rights, no PATH changes. Detection also scans common locations and your PATH automatically.
        </p>

        <div className="adv-row wide">
          <span className="adv-label">ffmpeg.exe path (optional override)</span>
          <input type="text" className="mono" placeholder="auto" value={settings.ffmpegPath || ''} onChange={(e) => setSettings({ ...settings, ffmpegPath: e.target.value })} onBlur={() => save({ ffmpegPath: settings.ffmpegPath })} />
        </div>
        <div className="adv-row wide">
          <span className="adv-label">ffprobe.exe path (optional override)</span>
          <input type="text" className="mono" placeholder="auto" value={settings.ffprobePath || ''} onChange={(e) => setSettings({ ...settings, ffprobePath: e.target.value })} onBlur={() => save({ ffprobePath: settings.ffprobePath })} />
        </div>
      </Card>

      <Card title="GPU / NVENC">
        <GpuPanel />
      </Card>

      <Card title="Output">
        <div className="adv-row wide">
          <span className="adv-label">Output folder for optimized files</span>
          <input type="text" className="mono" value={settings.outDir || ''} onChange={(e) => setSettings({ ...settings, outDir: e.target.value })} onBlur={() => save({ outDir: settings.outDir })} />
        </div>
        {settings.outDirSynced && (
          <p className="muted small warn-text">⚠ This folder is inside a cloud-synced location (OneDrive/iCloud/Dropbox). Mid-write syncs can corrupt outputs — a safe temp dir is used for work files regardless.</p>
        )}
        <div className="adv-row wide">
          <span className="adv-label">Temp work folder (must NOT be in OneDrive / cloud sync)</span>
          <input type="text" className="mono" placeholder={settings.tempDirEffective || 'auto'} value={settings.tempDir || ''} onChange={(e) => setSettings({ ...settings, tempDir: e.target.value })} onBlur={() => save({ tempDir: settings.tempDir })} />
        </div>
        <p className="muted small">
          Jobs write to a <span className="mono">.part.mp4</span> file in the temp folder and are moved to the output folder only after
          passing playback validation — interrupted jobs never leave files that look finished. Stale temp files are wiped automatically.
          Synced folders are refused for temp work. Current: <span className="mono">{settings.tempDirEffective}</span>
        </p>
        <div className="adv-row wide">
          <span className="adv-label">History entries to keep</span>
          <input type="number" min="10" max="2000" value={settings.historyLimit} onChange={(e) => setSettings({ ...settings, historyLimit: Number(e.target.value) })} onBlur={() => save({ historyLimit: settings.historyLimit })} />
        </div>
        <label className="check" style={{ marginTop: 8 }}>
          <input type="checkbox" checked={settings.preferGpu !== false} onChange={(e) => save({ preferGpu: e.target.checked })} />
          Prefer NVIDIA NVENC (GPU) encoding when available — falls back to CPU automatically
        </label>
        <div className="btn-row">
          <button className="btn" onClick={() => api.openFolder(settings.outDir)}>📂 Open output folder</button>
          <button className="btn" onClick={() => api.openFolder(settings.tempDirEffective)}>Open temp folder</button>
          <button className="btn" onClick={() => api.openFolder(settings.outDir.replace(/[\\/]+$/, ''))}>Open data folder</button>
        </div>
        <p className="muted small">History lives in <span className="mono">data/history.json</span> next to the app. Output files are never deleted by Forge.</p>
      </Card>
    </div>
  );
}

function GpuPanel() {
  const [info, setInfo] = React.useState(null);
  const [stats, setStats] = React.useState(null);
  const load = React.useCallback((refresh) => {
    api.gpu().then((d) => { setInfo(d.gpu); setStats(d.stats); }).catch(() => {});
  }, []);
  React.useEffect(() => { load(false); }, [load]);
  if (!info) return <p className="muted small">Detecting…</p>;
  if (!info.available) {
    return (
      <div>
        <div className={'ff-status bad'}>✕ {info.reason || 'No NVIDIA GPU detected'}</div>
        <p className="muted small">CPU encoding (libx264 / libx265) will be used. Remux jobs don't need a GPU.</p>
      </div>
    );
  }
  return (
    <div>
      <div className="ff-status ok">
        ✓ {info.name} — NVENC {info.nvenc.h264 || info.nvenc.hevc ? 'available' : 'unavailable in this FFmpeg build'}
        <span className="muted small"> ({info.reason})</span>
      </div>
      <div className="spec-grid">
        <Spec label="GPU" value={info.name} />
        <Spec label="Driver" value={info.driver} />
        <Spec label="NVENC H.264" value={info.nvenc.h264 ? 'h264_nvenc ✓' : '✕'} good={info.nvenc.h264} warn={!info.nvenc.h264} />
        <Spec label="NVENC H.265" value={info.nvenc.hevc ? 'hevc_nvenc ✓' : '✕'} good={info.nvenc.hevc} warn={!info.nvenc.hevc} />
        <Spec label="NVENC AV1" value={info.nvenc.av1 ? 'av1_nvenc ✓' : 'not available'} good={info.nvenc.av1} />
        <Spec label="GPU utilization" value={stats && stats.gpuUtil != null ? stats.gpuUtil + '%' : '—'} />
        <Spec label="VRAM" value={stats && stats.vramUsedMb != null ? (stats.vramUsedMb / 1024).toFixed(1) + ' / ' + (stats.vramTotalMb / 1024).toFixed(1) + ' GB' : '—'} />
        <Spec label="Encoder sessions" value={stats && stats.encSessions != null ? String(stats.encSessions) : '—'} />
        <Spec label="Encoder FPS" value={stats && stats.encFps != null ? String(stats.encFps) : '—'} />
        <Spec label="Temperature" value={stats && stats.tempC != null ? stats.tempC + '°C' : '—'} />
      </div>
      <div className="btn-row">
        <button className="btn" onClick={() => load(true)}>Re-detect NVENC</button>
      </div>
    </div>
  );
}
