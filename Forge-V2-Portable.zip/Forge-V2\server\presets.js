'use strict';
// Optimization presets. Default flow = lossless remux. Re-encode only when chosen.
// V2: creator preset set, GPU/CPU aware, HDR-aware, source-tuned bitrates.

const PRESETS = {
  remux: {
    id: 'remux', name: 'Lossless Remux', group: 'Universal',
    description: 'Zero re-encode. Rebuild the MP4/MOV container: moov atom front, clean metadata, corrected timestamps. Bit-identical video/audio.',
    mode: 'remux', icon: 'shield'
  },
  tiktok_ultra: {
    id: 'tiktok_ultra', name: 'TikTok Ultra Quality', group: 'TikTok',
    description: 'Keeps full resolution & fps as-is. Remux only when the source is already H.264/AAC; otherwise re-encode to platform-standard H.264 High @ max bitrate ceiling for minimal transcode damage.',
    mode: 'smart', icon: 'zap',
    target: { vcodec: 'h264', pixFmt: 'yuv420p', acodec: 'aac', container: 'mp4' }
  },
  tiktok_1080p60: {
    id: 'tiktok_1080p60', name: 'TikTok 1080p60', group: 'TikTok',
    description: '1080p (vertical or landscape as-is), 60 fps cap, H.264 High / yuv420p / AAC. Re-encodes only if needed.',
    mode: 'smart', icon: 'zap',
    target: { vcodec: 'h264', pixFmt: 'yuv420p', acodec: 'aac', container: 'mp4', maxFps: 60, scaleHeight: 1080 }
  },
  tiktok_4k60: {
    id: 'tiktok_4k60', name: 'TikTok 4K60', group: 'TikTok',
    description: 'Preserves up to 4K + 60 fps. H.264 High/yuv420p at a high bitrate ceiling. Remux-first when the source already matches.',
    mode: 'smart', icon: 'zap',
    target: { vcodec: 'h264', pixFmt: 'yuv420p', acodec: 'aac', container: 'mp4', maxFps: 60, scaleHeight: 2160 }
  },
  reels_hq: {
    id: 'reels_hq', name: 'Instagram Reels HQ', group: 'Instagram',
    description: '1080p H.264 High yuv420p + AAC. Same geometry, tuned for Instagram ingest.',
    mode: 'smart', icon: 'zap',
    target: { vcodec: 'h264', pixFmt: 'yuv420p', acodec: 'aac', container: 'mp4', maxFps: 60, scaleHeight: 1080 }
  },
  shorts_hq: {
    id: 'shorts_hq', name: 'YouTube Shorts HQ', group: 'YouTube',
    description: 'H.264/yuv420p/AAC, generous bitrate ceiling so YouTube gets a clean master.',
    mode: 'smart', icon: 'zap',
    target: { vcodec: 'h264', pixFmt: 'yuv420p', acodec: 'aac', container: 'mp4', maxFps: 60 }
  },
  archive_master: {
    id: 'archive_master', name: 'Archive Master', group: 'Universal',
    description: 'HEVC High Efficiency at near-transparent quality (CRF 18 / CQ 21). Biggest savings for long-term storage; slower to decode on old devices.',
    mode: 'smart', icon: 'archive',
    target: { vcodec: 'h265', pixFmt: 'yuv420p', acodec: 'aac', container: 'mp4' }
  }
};

function listPresets() {
  return Object.values(PRESETS).map((p) => ({ id: p.id, name: p.name, group: p.group, description: p.description, mode: p.mode, icon: p.icon }));
}

// Decide: can we hit the target with stream copy only? (V1 API preserved.)
function decideStrategy(probe, preset, adv) {
  adv = adv || {};
  if (preset.id === 'remux' || preset.mode === 'remux' || adv.forceRemux) {
    return { reencode: false, reason: 'Lossless remux selected — stream copy, no re-encode.' };
  }
  const t = preset.target || {};
  const v = probe.video, a = probe.audio;
  const reasons = [];
  let needsVideo = false, needsAudio = false;

  if (t.vcodec && v.codec !== t.vcodec) { needsVideo = true; reasons.push('video codec ' + v.codec + ' ≠ ' + t.vcodec); }
  if (t.pixFmt && v.pixFmt !== t.pixFmt) { needsVideo = true; reasons.push('pixel format ' + v.pixFmt + ' ≠ ' + t.pixFmt); }
  if (t.scaleHeight && v.height && v.height > t.scaleHeight) { needsVideo = true; reasons.push(v.height + 'p downscales to ' + t.scaleHeight + 'p'); }
  if (t.maxFps && v.fps && v.fps > t.maxFps + 0.5) { needsVideo = true; reasons.push(v.fps + ' fps capped to ' + t.maxFps); }
  if (t.acodec && a && a.codec !== t.acodec) { needsAudio = true; reasons.push('audio codec ' + a.codec + ' ≠ ' + t.acodec); }
  if (!a && t.acodec) { reasons.push('no audio stream to convert'); needsAudio = false; }

  // Container must be remuxable to mp4 regardless.
  if (!needsVideo && !needsAudio) {
    return { reencode: false, reason: 'Source already matches target codec/pixel/fps — lossless stream copy + container optimization.' };
  }
  return { reencode: true, reencodeVideo: needsVideo, reencodeAudio: needsAudio, reason: 'Re-encode required: ' + reasons.join('; ') + '.' };
}

// ---- encoder choice ----
const VBR_CEILINGS = {
  // generous maxrate ceilings (kbps) per output height tier — "clean master" targets
  h264: { 720: 12000, 1080: 24000, 1440: 35000, 2160: 80000, 4320: 160000 },
  hevc: { 720: 9000, 1080: 18000, 1440: 28000, 2160: 66000, 4320: 140000 }
};

function ceilingKbps(codec, height) {
  const t = VBR_CEILINGS[codec] || VBR_CEILINGS.h264;
  if (!height) return t[1080];
  for (const tier of [720, 1080, 1440, 2160, 4320]) if (height <= tier) return t[tier];
  return t[4320];
}

function is10Bit(pixFmt) { return /10le|10be|p010|p016/.test(String(pixFmt || '')); }

function isHdrish(v) {
  return v && (/2020|arib|smpte|p10/.test(String(v.pixFmt || '') + String(v.colorSpace || '') + String(v.colorTransfer || '') + String(v.colorPrimaries || '')) || is10Bit(v.pixFmt));
}

function nvencPixFmt(pixFmt) { return is10Bit(pixFmt) ? 'p010le' : 'yuv420p'; }

function nvencProfile(codec, pixFmt) {
  if (is10Bit(pixFmt)) return codec === 'hevc' ? 'main10' : 'high10';
  return codec === 'hevc' ? 'main' : 'high';
}

// Pick video codec + encoder. accel ∈ 'gpu' | 'cpu'.
// NVENC H.264 cannot encode 10-bit on consumer GPUs (RTX 30xx: H.264 = 8-bit only),
// so for 10-bit HDR sources H.264 GPU encode is impossible — use hevc_nvenc (main10)
// on GPU when the source is 10-bit and no explicit codec was requested.
function pickEncoder({ probe, adv, gpu }) {
  const t = adv.target || {};
  const src10 = is10Bit(probe && probe.video && probe.video.pixFmt);
  let preferHevc = adv.hevc === true || t.vcodec === 'h265' || t.vcodec === 'hevc';
  const gpuCanH264 = gpu && gpu.available && gpu.nvenc.h264;
  const gpuCanHevc = gpu && gpu.available && gpu.nvenc.hevc;
  if (src10 && !preferHevc) {
    // H.264 requested but source is 10-bit: on GPU this must go hevc (main10).
    if (adv.encoder === 'cpu') {
      return { codec: 'h264', encoder: 'libx264', accel: 'cpu', note: '10-bit source — CPU H.264 (libx264 high10)' };
    }
    if (gpuCanHevc) {
      return { codec: 'hevc', encoder: 'hevc_nvenc', accel: 'gpu', note: '10-bit HDR source — GPU HEVC Main10 (NVENC H.264 is 8-bit only)' };
    }
    return { codec: 'h264', encoder: 'libx264', accel: 'cpu', note: '10-bit source but no HEVC NVENC — CPU fallback' };
  }
  const gpuCan = preferHevc ? gpuCanHevc : gpuCanH264;
  if (adv.encoder !== 'cpu' && gpuCan) {
    return { codec: preferHevc ? 'hevc' : 'h264', encoder: (preferHevc ? 'hevc_nvenc' : 'h264_nvenc'), accel: 'gpu' };
  }
  return { codec: preferHevc ? 'hevc' : 'h264', encoder: preferHevc ? 'libx265' : 'libx264', accel: 'cpu' };
}

// Build the actual ffmpeg args for a job. V1 signature/behavior preserved;
// adv.gpu (detection result) + adv.encoder ('gpu'|'cpu'|'auto') steer NVENC.
function buildArgs({ input, output, probe, strategy, adv }) {
  adv = adv || {};
  const args = [];
  if (adv.overwrite !== false) args.push('-y');
  if (adv.genpts) args.push('-genpts');
  args.push('-i', input);
  const v = probe.video;
  const clear = adv.stripMetadata !== false; // default: clean slate
  if (clear) {
    args.push('-map_metadata', '-1');
    args.push('-map', '0:v:0', '-map', a_or_null(probe) ? '0:a:0?' : '0:a?');
  } else {
    args.push('-map', '0:v:0', a_or_null(probe) ? '0:a:0?' : '0:a?');
  }
  if (adv.removeDataStreams !== false) args.push('-dn'); // drop tmcd/data streams
  args.push('-map_chapters', '-1');

  if (!strategy.reencode) {
    args.push('-c', 'copy');
  } else {
    const t = (adv.target) || {};
    if (strategy.reencodeVideo) {
      const enc = pickEncoder({ probe, adv, gpu: adv.gpu });
      const gpu = enc.accel === 'gpu';
      const is10 = is10Bit(v.pixFmt);

      args.push('-c:v', enc.encoder);
      if (gpu && !adv.sdrConvert) {
        args.push('-preset', String(adv.nvencPreset || 'p6'));
        if (adv.nvencTune !== false) args.push('-tune', String(adv.nvencTune || 'hq'));
        args.push('-rc', 'vbr', '-cq', String(adv.nvencCq != null ? adv.nvencCq : (enc.codec === 'hevc' ? 24 : 21)), '-b:v', '0');
        const ceil = adv.bitrateCeilingKbps || ceilingKbps(enc.codec, outHeight(v, t));
        args.push('-maxrate', ceil + 'k', '-bufsize', (ceil * 2) + 'k');
        args.push('-pix_fmt', nvencPixFmt(v.pixFmt));
        args.push('-profile:v', nvencProfile(enc.codec, v.pixFmt));
        if (adv.nvencSpatialAq !== false) args.push('-spatial-aq', '1');
      } else if (gpu && adv.sdrConvert) {
        // SDR conversion: output is 8-bit yuv420p regardless of source depth
        args.push('-preset', String(adv.nvencPreset || 'p6'));
        if (adv.nvencTune !== false) args.push('-tune', String(adv.nvencTune || 'hq'));
        args.push('-rc', 'vbr', '-cq', String(adv.nvencCq != null ? adv.nvencCq : (enc.codec === 'hevc' ? 24 : 21)), '-b:v', '0');
        const ceil = adv.bitrateCeilingKbps || ceilingKbps(enc.codec, outHeight(v, t));
        args.push('-maxrate', ceil + 'k', '-bufsize', (ceil * 2) + 'k');
        args.push('-pix_fmt', 'yuv420p');
        args.push('-profile:v', enc.codec === 'hevc' ? 'main' : 'high');
        if (adv.nvencSpatialAq !== false) args.push('-spatial-aq', '1');
      } else if (enc.codec === 'hevc') {
        args.push('-preset', adv.x264Preset || 'slow');
        args.push('-crf', String(adv.crf != null ? adv.crf : 20));
        args.push('-pix_fmt', 'yuv420p');
        if (adv.bitrateCeilingKbps) args.push('-maxrate', adv.bitrateCeilingKbps + 'k', '-bufsize', (adv.bitrateCeilingKbps * 2) + 'k');
      } else {
        args.push('-preset', adv.x264Preset || 'slow');
        args.push('-crf', String(adv.crf != null ? adv.crf : 17));
        args.push('-profile:v', adv.h264Profile || 'high');
        args.push('-pix_fmt', 'yuv420p');
        if (adv.bitrateCeilingKbps) args.push('-maxrate', adv.bitrateCeilingKbps + 'k', '-bufsize', (adv.bitrateCeilingKbps * 2) + 'k');
      }

      const filters = [];
      if (t.scaleHeight && v.height && v.height > t.scaleHeight) filters.push('scale=-2:' + t.scaleHeight);
      if (t.maxFps && v.fps && v.fps > t.maxFps + 0.5) filters.push('fps=' + t.maxFps);
      // color metadata: keep HDR tags unless user asks SDR conversion
      if (adv.sdrConvert && /10|2020|arib|smpte/.test(String(v.pixFmt || '') + String(v.colorSpace || '') + String(v.colorTransfer || '') + String(v.colorPrimaries || ''))) {
        filters.push('format=yuv420p');
        args.push('-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709');
      } else {
        if (v.colorSpace) args.push('-colorspace', v.colorSpace);
        if (v.colorPrimaries) args.push('-color_primaries', v.colorPrimaries);
        if (v.colorTransfer) args.push('-color_trc', v.colorTransfer);
      }
      if (filters.length) args.push('-vf', filters.join(','));
      if (adv.fpsMeta && (!t.maxFps || v.fps <= t.maxFps + 0.5)) args.push('-r', String(adv.fpsMeta));
    } else {
      args.push('-c:v', 'copy');
    }
    if (strategy.reencodeAudio) {
      args.push('-c:a', 'aac', '-b:a', String(adv.audioBitrateKbps || 256) + 'k', '-ar', '48000', '-ac', '2');
    } else {
      args.push('-c:a', 'copy');
    }
  }

  if (adv.faststart !== false) args.push('-movflags', '+faststart');
  args.push('-metadata', 'encoder=Forge Local Optimizer');
  if (adv.comment) args.push('-metadata', 'comment=' + String(adv.comment).slice(0, 200));
  args.push('-f', adv.containerFormat || 'mp4');
  args.push(output);
  return args;
}

function outHeight(v, t) {
  if (t.scaleHeight && v.height && v.height > t.scaleHeight) return t.scaleHeight;
  return v.height || 1080;
}

function a_or_null(probe) { return !!(probe && probe.audio); }

// ---- Smart recommendation (V2) ----
function recommendPreset(probe, gpu) {
  const v = probe.video, a = probe.audio;
  const reasons = [];
  const vertical = v.width && v.height && v.height > v.width;

  // 1) Already a clean social master? → Lossless Remux, zero generation loss.
  const clean = v.codec === 'h264' && v.pixFmt === 'yuv420p' && a && a.codec === 'aac'
    && (!v.fps || v.fps <= 61) && v.height && v.height <= 2160;
  if (clean) {
    return { presetId: 'remux', confidence: 'high', reasons: ['H.264 · yuv420p · AAC, ≤4K and ≤60 fps — nothing to fix'] };
  }

  // 2) 4K-class source keeps its resolution.
  if (v.height && v.height >= 1440) {
    reasons.push(v.height + 'p — 4K-class resolution preserved');
    if (v.fps && v.fps > 60.5) reasons.push(v.fps + ' fps capped to 60 for platform smoothness');
    if (!clean) {
      if (v.codec !== 'h264') reasons.push(v.codec + ' → H.264 for maximum platform compatibility');
      if (v.pixFmt !== 'yuv420p') reasons.push(v.pixFmt + ' → yuv420p 8-bit');
      if (!a || a.codec !== 'aac') reasons.push('audio → AAC');
    }
    reasons.push(gpu && gpu.nvenc.h264 ? 'NVENC available — high-res transcode fast on GPU' : 'no NVENC — CPU fallback will be slower');
    return { presetId: 'tiktok_4k60', confidence: 'high', reasons };
  }

  // 3) Sub-HD: normalize without upscaling.
  if (v.height && v.height < 720) {
    reasons.push(v.height + 'p low-res — normalize codec/pixel format, never upscale');
    if (v.pixFmt !== 'yuv420p') reasons.push(v.pixFmt + ' → yuv420p 8-bit');
    if (v.codec !== 'h264') reasons.push(v.codec + ' → H.264 for maximum compatibility');
    if (!a || a.codec !== 'aac') reasons.push('audio → AAC');
    // Source needs a real transcode → 1080p60 preset is wrong for low-res;
    // Ultra Quality keeps resolution as-is.
    if (v.codec !== 'h264' || v.pixFmt !== 'yuv420p' || !a || a.codec !== 'aac') {
      return { presetId: 'tiktok_ultra', confidence: 'medium', reasons };
    }
    // Already clean → plain remux is enough.
    return { presetId: 'remux', confidence: 'high', reasons: ['Sub-HD but already H.264/yuv420p/AAC — clean remux only'] };
  }

  // 4) Creator sweet spot.
  reasons.push('1080p creator standard — ' + (vertical ? 'vertical' : 'landscape') + ' geometry kept');
  if (v.fps && v.fps > 60.5) reasons.push(v.fps + ' fps capped to 60');
  if (v.codec !== 'h264') reasons.push(v.codec + ' → H.264 for maximum compatibility');
  if (v.pixFmt !== 'yuv420p') reasons.push(v.pixFmt + ' → yuv420p 8-bit');
  if (!a || a.codec !== 'aac') reasons.push('audio → AAC');
  return { presetId: 'tiktok_ultra', confidence: 'medium', reasons };
}

module.exports = {
  PRESETS, listPresets, decideStrategy, buildArgs,
  pickEncoder, recommendPreset, ceilingKbps, nvencPixFmt, nvencProfile, is10Bit, isHdrish
};
