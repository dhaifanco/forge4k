import React from 'react';
import { api } from '../api';
import { Card, Spec, Badge, Dot, DropZone, ErrorBar } from '../ui.jsx';

export default function Analyzer() {
  const [phase, setPhase] = React.useState('idle');
  const [info, setInfo] = React.useState(null);
  const [error, setError] = React.useState(null);

  async function onFile(file) {
    setError(null); setInfo(null); setPhase('analyzing');
    try {
      const d = await api.analyze(file);
      setInfo(d); setPhase('ready');
    } catch (e) { setError(e.message); setPhase('idle'); }
  }

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>Video Analyzer</h1>
          <p className="page-sub">Full FFprobe inspection — resolution, fps, bitrate, codecs, color, metadata.</p>
        </div>
      </header>

      <ErrorBar>{error}</ErrorBar>

      {phase === 'idle' && <DropZone onFile={onFile} label="Drop a video to inspect" />}
      {phase === 'analyzing' && <div className="card center-card"><div className="spinner" /> Probing…</div>}

      {phase === 'ready' && info && (
        <>
          <div className="grid-2">
            <Card title="Container" right={<Badge kind={info.format.container === 'mp4' ? 'good' : 'warn'}>{info.format.container.toUpperCase()}</Badge>}>
              <div className="spec-grid">
                <Spec label="File" value={info.file.name} />
                <Spec label="Size" value={info.file.size && info.file.size.human} />
                <Spec label="Duration" value={info.format.durationHuman} />
                <Spec label="Overall bitrate" value={info.format.overallBitrate} />
                <Spec label="Start time" value={info.format.start} />
                <Spec label="Streams" value={info.streams.map((s) => s.type).join(', ')} />
              </div>
            </Card>
            <Card title="Video Stream" right={<Badge kind={info.video.codec === 'h264' ? 'good' : 'warn'}>{info.video.codec}</Badge>}>
              <div className="spec-grid">
                <Spec label="Codec" value={[info.video.codec, info.video.profile, info.video.level != null ? 'L' + info.video.level : null].filter(Boolean).join(' · ')} />
                <Spec label="Resolution" value={info.video.resolution} />
                <Spec label="FPS (avg)" value={info.video.fps} />
                <Spec label="FPS raw" value={info.video.fpsRaw && (info.video.fpsRaw.avg + ' / ' + info.video.fpsRaw.r)} />
                <Spec label="Bitrate" value={info.video.bitrate} />
                <Spec label="Pixel format" value={info.video.pixFmt + ' (' + (info.video.bitDepth || '?') + '-bit)'} good={info.video.pixFmt === 'yuv420p'} />
                <Spec label="Frames" value={info.video.nbFrames} />
                <Spec label="Field order" value={info.video.fieldOrder} />
              </div>
            </Card>
          </div>

          <div className="grid-2">
            <Card title="Color Metadata" right={info.video.isHdr ? <Badge kind="warn">HDR</Badge> : <Badge kind="good">SDR</Badge>}>
              <div className="spec-grid">
                <Spec label="Color space" value={info.video.colorSpace} />
                <Spec label="Transfer" value={info.video.colorTransfer} />
                <Spec label="Primaries" value={info.video.colorPrimaries} />
                <Spec label="Chroma location" value={info.video.chromaLocation} />
              </div>
              <p className="muted small">Untagged color is normal for phone footage — platforms assume BT.709. HDR tags survive a remux untouched.</p>
            </Card>
            <Card title="Audio" right={info.audio ? <Badge kind={info.audio.codec === 'aac' ? 'good' : 'warn'}>{info.audio.codec}</Badge> : <Badge>none</Badge>}>
              {info.audio ? (
                <div className="spec-grid">
                  <Spec label="Codec" value={[info.audio.codec, info.audio.profile].filter(Boolean).join(' · ')} />
                  <Spec label="Sample rate" value={info.audio.sampleRate} />
                  <Spec label="Channels" value={info.audio.channels + ' (' + (info.audio.channelLayout || '?') + ')'} />
                  <Spec label="Bitrate" value={info.audio.bitrate} />
                </div>
              ) : <p className="muted">No audio stream.</p>}
            </Card>
          </div>

          <div className="grid-2">
            <Card title="Compatibility Checks">
              <ul className="health-list">
                <Compat label="MP4 faststart-friendly container" ok={info.format.container === 'mp4'} note={info.format.container === 'mp4' ? 'MP4' : 'will be remuxed to MP4 on optimize'} />
                <Compat label="H.264 video" ok={info.video.codec === 'h264'} note={info.video.codec === 'h264' ? 'maximum compatibility' : info.video.codec === 'hevc' ? 'H.265 — some platforms re-encode or reject' : 'non-standard for social upload'} />
                <Compat label="yuv420p 8-bit" ok={info.video.pixFmt === 'yuv420p'} note={info.video.pixFmt === 'yuv420p' ? 'universally compatible' : 'may trigger platform transcode'} />
                <Compat label="AAC audio" ok={!!info.audio && info.audio.codec === 'aac'} note={!info.audio ? 'no audio' : info.audio.codec === 'aac' ? 'platform standard' : info.audio.codec + ' — convert to AAC recommended'} />
                <Compat label="≤ 4K resolution" ok={!info.video.height || info.video.height <= 2160} note={info.video.height && info.video.height > 2160 ? info.video.height + 'p exceeds platform maxima' : 'within range'} />
                <Compat label="HDR tags present" warn-only="1" ok={!info.video.isHdr} note={info.video.isHdr ? 'HDR detected — fine for HDR-aware feeds, may look off on SDR' : 'none — safe'} />
              </ul>
            </Card>
            <Card title="Container Metadata (read-only)">
              <pre className="meta-json">{Object.keys(info.metadata || {}).length ? JSON.stringify(info.metadata, null, 2) : 'No container-level tags.'}</pre>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}

function Compat({ label, ok, note }) {
  return (
    <li className="finding">
      <Dot ok={ok} warn={ok} />
      <span><strong>{label}</strong> <span className="muted">— {note}</span></span>
    </li>
  );
}
