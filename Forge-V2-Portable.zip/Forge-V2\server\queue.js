'use strict';
// V2 batch queue: sequential job runner with statuses, retry, remove, cancel.
// Keeps the V1 single-job API intact (JOBS map + /api/optimize/:id polling).

const fs = require('fs');
const path = require('path');
const store = require('./store');
const ff = require('./ffmpeg');
const presetsMod = require('./presets');
const gpuMod = require('./gpu');
const { PRESETS, decideStrategy, buildArgs } = presetsMod;

// Single source of truth for job records. V1 /api/optimize writes here too.
const JOBS = new Map();
const QUEUE = [];           // ordered job ids
let running = false;
let gpuCache = null;        // refreshed before each job

const MAX_DONE_JOBS = 60;

function newId(prefix) {
  return (prefix || 'job') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function jobSnapshot(j) {
  // strip non-serializable fields for API responses
  const { child, ...safe } = j;
  return safe;
}

function getJob(id) { return JOBS.get(id); }

function listJobs() {
  // QUEUE holds every job (running/finished stay until removed by the user or
  // pruned); jobs whose record vanished are skipped defensively.
  return QUEUE.map((id) => jobSnapshot(JOBS.get(id))).filter(Boolean);
}

// enqueue(payload): { inputPath, sourceName, presetId, adv, sourcePath (original), keepInput }
function enqueue(payload) {
  const id = newId('job');
  const job = {
    id,
    state: 'waiting',           // waiting | processing | completed | failed | cancelled
    status: 'waiting',          // alias used by V1 UI
    presetId: payload.presetId || 'remux',
    sourceName: payload.sourceName || path.basename(payload.inputPath),
    sourcePath: payload.sourcePath || payload.inputPath,
    createdAt: new Date().toISOString(),
    progress: null,
    logLines: [],
    cancelRequested: false,
    _payload: payload
  };
  JOBS.set(id, job);
  QUEUE.push(id);
  prune();
  setImmediate(pump);
  return jobSnapshot(job);
}

function remove(id) {
  const j = JOBS.get(id);
  if (!j) return false;
  if (j.state === 'processing') {
    j.cancelRequested = true;
    if (j.child) { try { j.child.kill('SIGKILL'); } catch (e) {} }
    j._removeAfterCancel = true;
    return true;
  }
  // Reclaim the staged input of a never-finished job (cancelled/failed jobs keep their
  // input alive for Retry — deleting the job must not leak it in data/uploads).
  if (['cancelled', 'failed'].includes(j.state) && j._payload && j._payload.inputPath) {
    try { if (fs.existsSync(j._payload.inputPath) && j._payload.keepInput !== true) fs.unlinkSync(j._payload.inputPath); } catch (e) {}
  }
  const qi = QUEUE.indexOf(id);
  if (qi >= 0) QUEUE.splice(qi, 1);
  JOBS.delete(id);
  return true;
}

function retry(id) {
  const j = JOBS.get(id);
  if (!j) return null;
  if (j.state === 'processing' || j.state === 'waiting') return jobSnapshot(j);
  // re-enqueue a fresh job with the same payload
  if (!j._payload || !fs.existsSync(j._payload.inputPath)) {
    j.error = 'Cannot retry — source file no longer staged. Drop the file again.';
    return jobSnapshot(j);
  }
  return enqueue(j._payload);
}

function cancel(id) {
  const j = JOBS.get(id);
  if (!j) return false;
  if (j.state === 'waiting') {
    j.state = 'cancelled'; j.status = 'cancelled';
    j.error = 'Cancelled before start';
    j.finishedAt = new Date().toISOString();
    // Keep the id in QUEUE so the job still shows up in /api/queue as Cancelled —
    // splicing it out orphans the record (in JOBS but invisible in listJobs).
    setImmediate(pump);
    return true;
  }
  if (j.state === 'processing') {
    j.cancelRequested = true;
    if (j.child) { try { j.child.kill('SIGKILL'); } catch (e) {} }
    return true;
  }
  return false;
}

function cancelAll() {
  for (const id of [...QUEUE]) cancel(id);
}

async function pump() {
  if (running) return;
  const nextId = QUEUE.find((id) => JOBS.get(id) && JOBS.get(id).state === 'waiting');
  if (!nextId) { running = false; return; }
  running = true;
  const job = JOBS.get(nextId);
  job.state = 'processing'; job.status = 'processing';
  job.startedAt = new Date().toISOString();
  try {
    await runJob(job);
  } catch (e) {
    job.state = 'failed'; job.status = 'failed';
    job.error = String(e.message || e);
    cleanupJobFiles(job, false);
  }
  job.finishedAt = new Date().toISOString();
  if (job._removeAfterCancel) { JOBS.delete(nextId); }
  prune();
  running = false;
  setImmediate(pump);
}

function prune() {
  // keep memory bounded: only finished jobs past MAX_DONE_JOBS are dropped
  // (and pruned records are also taken out of QUEUE so listJobs stays clean)
  const done = [...JOBS.entries()].filter(([, j]) => ['completed', 'failed', 'cancelled'].includes(j.state));
  done.sort((a, b) => String(a[1].finishedAt || '').localeCompare(String(b[1].finishedAt || '')));
  while (done.length > MAX_DONE_JOBS) {
    const [id] = done.shift();
    JOBS.delete(id);
    const qi = QUEUE.indexOf(id);
    if (qi >= 0) QUEUE.splice(qi, 1);
  }
}

async function currentGpu(force) {
  if (!gpuCache || force || (Date.now() - gpuCache.checkedAt) > 60000) {
    const bins = await ff.locateBinaries();
    gpuCache = await gpuMod.detectGpu(bins.ffmpegPath, force);
  }
  return gpuCache;
}

async function runJob(job) {
  const payload = job._payload;
  const { inputPath, presetId, adv } = payload;
  const settings = store.getSettings();
  let advUser = {};
  try { advUser = typeof adv === 'string' ? JSON.parse(adv) : (adv || {}); } catch (e) {}

  const bins = await ff.locateBinaries();
  if (!bins.ok) throw new Error('FFmpeg not found — run setup in Settings first.');

  const pr = await ff.probe(inputPath);
  if (!pr.ok) throw new Error('Could not read source: ' + (pr.error || 'ffprobe failed'));

  const before = ff.normalizeProbe(pr.data, inputPath);
  const presetDef = PRESETS[presetId] || PRESETS.remux;
  const gpu = await currentGpu();
  const useGpu = settings.preferGpu !== false && advUser.encoder !== 'cpu';
  const strategy = decideStrategy(before, presetDef, advUser);
  const advFull = Object.assign({}, advUser, presetDef.target ? { target: presetDef.target } : {});
  advFull.gpu = useGpu ? gpu : null;
  if (strategy.reencode && strategy.reencodeVideo) {
    // Same gate as the args: pass the useGpu-filtered value, not raw detection,
    // or a preferGpu=false job would be labeled "GPU ENCODE" (BUG-2).
    const enc = presetsMod.pickEncoder({ probe: before, adv: advFull, gpu: useGpu ? gpu : null });
    advFull.encoderResolved = enc.accel;           // gpu | cpu
    advFull.encoderName = enc.encoder;             // h264_nvenc | hevc_nvenc | libx264 | libx265
    advFull.accelLabel = enc.accel === 'gpu' ? 'GPU ENCODE' : 'CPU ENCODE';
  } else if (!strategy.reencode) {
    advFull.encoderResolved = 'copy';
    advFull.accelLabel = 'LOSSLESS REMUX';
  }

  // Atomic output: write to <name>.part.mp4 in temp, then rename into place.
  const outDir = advUser.outDir || settings.outDir;
  store.ensureDir(outDir);
  const tempDir = store.getSettings().tempDirEffective;
  store.ensureDir(tempDir);
  const finalName = uniqueOutPath(outDir, buildOutputName(before.file.name, presetDef));
  const tmpOutput = path.join(tempDir, job.id + '.part.mp4');

  const args = buildArgs({ input: inputPath, output: tmpOutput, probe: before, strategy, adv: advFull });
  job.command = 'ffmpeg ' + args.join(' ');
  job.accel = advFull.accelLabel;
  job.encoderName = advFull.encoderName || 'copy';
  job.presetName = presetDef.name;
  job.reason = strategy.reason;
  job.outputFinal = finalName;
  job.outDir = outDir;

  const durationSec = before.format.durationSec || 0;
  const t0 = Date.now();
  let lastLog = 0;

  const run = await ff.runBin(bins.ffmpegPath, args, {
    timeoutMs: 1000 * 60 * 60 * 3,
    onSpawn: (child) => { job.child = child; },
    onProgressKv: (kv) => {
      // Progress starts emitting after the first frames; ignore N/A before that.
      const outTime = parseTimeUs(kv.out_time_us != null ? kv.out_time_us : kv.out_time_ms);
      const pct = durationSec > 0 && outTime > 0 ? Math.min(100, (outTime / durationSec) * 100) : null;
      if (pct == null && !kv.frame) return;
      job.progress = {
        pct: pct != null ? Math.round(pct * 10) / 10 : (kv.frame ? 0 : null),
        frame: Number(kv.frame) || null,
        fps: kv.fps && kv.fps !== 'N/A' ? Number(kv.fps) : null,
        speed: kv.speed && kv.speed !== 'N/A' ? String(kv.speed) : null,
        outTimeSec: outTime,
        totalSec: durationSec || null,
        elapsedMs: Date.now() - t0,
        etaSec: pct != null && pct > 0.5 ? Math.max(0, Math.round(((Date.now() - t0) / pct) * (100 - pct) / 1000)) : null,
        sizeBytes: kv.total_size && kv.total_size !== 'N/A' ? Number(kv.total_size) || null : null,
        bitrate: kv.bitrate && kv.bitrate !== 'N/A' ? kv.bitrate : null
      };
      // throttle log sample lines (progress kv carries the useful data)
      const now = Date.now();
      if (now - lastLog > 2000) {
        lastLog = now;
        job.logLines.push('frame=' + (kv.frame || '?') + ' fps=' + (kv.fps || '?') + ' speed=' + (kv.speed || '?') + ' time=' + (kv.out_time || '?') + ' size=' + (kv.total_size || '?'));
        if (job.logLines.length > 200) job.logLines.splice(0, job.logLines.length - 200);
      }
    },
    onLog: (chunk) => {
      for (const l of chunk.split(/\r?\n/)) {
        const t = l.trim();
        if (!t) continue;
        job.logLines.push(t);
        if (job.logLines.length > 200) job.logLines.splice(0, job.logLines.length - 200);
      }
    }
  });

  if (job.cancelRequested) {
    job.state = 'cancelled'; job.status = 'cancelled';
    job.error = 'Cancelled';
    cleanupJobFiles(job, false);
    return;
  }
  if (run.code !== 0 || !fs.existsSync(tmpOutput) || fs.statSync(tmpOutput).size === 0) {
    job.state = 'failed'; job.status = 'failed';
    job.error = lastErr(run.stderr) || ('FFmpeg exited with code ' + run.code);
    job.logTail = (run.logLines || []).slice(-40);
    cleanupJobFiles(job, false);
    return;
  }

  // Playback validation before the output counts as completed.
  const validation = await ff.validatePlayback(tmpOutput);
  if (!validation.ok) {
    job.state = 'failed'; job.status = 'failed';
    job.error = 'Output failed playback validation: ' + (validation.error || 'decode error');
    job.logTail = (run.logLines || []).slice(-40);
    cleanupJobFiles(job, false);
    return;
  }

  // Atomic finalize: move into the output folder only now.
  try {
    fs.renameSync(tmpOutput, finalName);
  } catch (e) {
    // cross-device rename: copy+delete fallback
    try {
      fs.copyFileSync(tmpOutput, finalName);
      fs.unlinkSync(tmpOutput);
    } catch (e2) {
      job.state = 'failed'; job.status = 'failed';
      job.error = 'Could not move output into place: ' + String(e2.message || e2);
      cleanupJobFiles(job, false);
      return;
    }
  }

  let after = null;
  const pr2 = await ff.probe(finalName);
  if (pr2.ok) after = ff.normalizeProbe(pr2.data, finalName);

  job.state = 'completed'; job.status = 'done';
  job.result = {
    id: job.id,
    preset: presetDef.id, presetName: presetDef.name,
    mode: strategy.reencode ? 're-encode' : 'lossless remux',
    accel: advFull.accelLabel,
    encoder: advFull.encoderName || 'stream copy',
    reason: strategy.reason,
    source: before.file,
    beforeSpecs: before,
    output: { name: path.basename(finalName), path: finalName, dir: outDir, size: after ? after.file.size : null },
    afterSpecs: after,
    validation,
    status: 'done',
    durationMs: Date.now() - t0,
    startedAt: job.startedAt, finishedAt: new Date().toISOString(),
    command: job.command
  };
  store.addHistory(job.result);
  cleanupJobFiles(job, true);
  job._payload = null; // input consumed (V1 deletes staged uploads on success)
  try { if (payload.inputPath && payload.keepInput !== true && fs.existsSync(payload.inputPath)) fs.unlinkSync(payload.inputPath); } catch (e) {}
}

function cleanupJobFiles(job, success) {
  const payload = job._payload || {};
  try {
    if (job.outputFinal && !fs.existsSync(job.outputFinal)) { /* nothing */ }
    const tmp = path.join(store.getSettings().tempDirEffective, job.id + '.part.mp4');
    if (fs.existsSync(tmp)) fs.unlinkSync(tmp);
  } catch (e) {}
  // failed + cancelled: KEEP the staged input — the UI offers Retry for both, and Retry
  // needs the source. remove()/clear-finished reclaim the input when the user deletes
  // the job instead of retrying (BUG-4: Retry used to be a dead button on failed jobs).
}

function parseTimeUs(v) {
  if (v == null || v === 'N/A' || v === '') return 0;
  if (String(v).includes(':')) {
    // hh:mm:ss.micro
    const [h, m, s] = String(v).split(':').map(Number);
    return (h || 0) * 3600 + (m || 0) * 60 + (s || 0);
  }
  const n = Number(v);
  if (!isFinite(n)) return 0;
  // out_time_us field is microseconds; out_time_ms is actually also microseconds in ffmpeg
  return n / 1e6;
}

function lastErr(stderr) {
  if (!stderr) return null;
  const lines = stderr.trim().split(/\r?\n/);
  for (let i = lines.length - 1; i >= 0; i--) {
    const l = lines[i].trim();
    if (/^(ERROR|Error|Invalid|Could not|Unable|Conversion failed|Unknown|At least one)/i.test(l)) return l.slice(0, 300);
  }
  return lines[lines.length - 1].slice(0, 300) || null;
}

function buildOutputName(srcName, presetDef) {
  const base = srcName.replace(/\.[^./\\]+$/, '').slice(0, 120) || 'video';
  return base + ' [optimized ' + presetDef.id + '].mp4';
}

function uniqueOutPath(dir, name) {
  let candidate = path.join(dir, name);
  if (!fs.existsSync(candidate)) return candidate;
  const base = name.replace(/\.mp4$/i, '');
  for (let i = 2; i < 500; i++) {
    candidate = path.join(dir, base + ' (' + i + ').mp4');
    if (!fs.existsSync(candidate)) return candidate;
  }
  return path.join(dir, base + ' (' + Date.now() + ').mp4');
}

module.exports = { JOBS, enqueue, remove, retry, cancel, cancelAll, getJob, listJobs, pump, currentGpu, buildOutputName, uniqueOutPath, lastErr };
