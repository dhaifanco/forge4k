import React from 'react';
import { api, fmtBytes, fmtDur } from '../api';
import { Card, Spec, Badge, Dot, DropZone, ErrorBar, LogViewer, ProgressPanel } from '../ui.jsx';

const DEFAULT_ADV = {
  stripMetadata: true,
  faststart: true,
  removeDataStreams: true,
  genpts: false,
  forceRemux: false,
  sdrConvert: false,
  crf: 17,
  x264Preset: 'slow',
  audioBitrateKbps: 256,
  fpsMeta: '',
  comment: '',
  encoder: 'auto' // auto | gpu | cpu
};

const QUEUE_POLL_MS = 700;

export default function Optimizer() {
  const [items, setItems] = React.useState([]);       // batch: analyzed sources
  const [phase, setPhase] = React.useState('idle');   // idle | analyzing | ready
  const [presets, setPresets] = React.useState([]);
  const [presetSel, setPresetSel] = React.useState({});   // itemId -> presetId
  const [applyAll, setApplyAll] = React.useState('');      // bulk preset
  const [queue, setQueue] = React.useState([]);
  const [gpu, setGpu] = React.useState(null);
  const [gpuStats, setGpuStats] = React.useState(null);
  const [error, setError] = React.useState(null);
  const [settings, setSettings] = React.useState(null);
  const [expandedLog, setExpandedLog] = React.useState(null);

  React.useEffect(() => {
    api.presets().then((d) => setPresets(d.presets)).catch(() => {});
    api.health().then(setSettings).catch(() => {});
    api.gpu().then((d) => setGpu(d.gpu)).catch(() => {});
  }, []);

  // queue polling loop (only while something is pending/running)
  React.useEffect(() => {
    let stop = false;
    let timer = null;
    async function tick() {
      try {
        const d = await api.queue();
        if (stop) return;
        setQueue(d.items || []);
        const busy = (d.items || []).some((j) => j.state === 'waiting' || j.state === 'processing');
        timer = setTimeout(tick, busy ? QUEUE_POLL_MS : 2500);
        if (!busy) {
          // refresh GPU stats only occasionally when idle
          api.gpuStats().then((g) => setGpuStats(g.stats)).catch(() => {});
        } else if (gpu && gpu.available) {
          api.gpuStats().then((g) => setGpuStats(g.stats)).catch(() => {});
        }
      } catch (e) {
        if (!stop) timer = setTimeout(tick, 2000);
      }
    }
    tick();
    return () => { stop = true; clearTimeout(timer); };
  }, [gpu]);

  async function onFiles(files) {
    setError(null);
    setPhase('analyzing');
    try {
      const d = await api.analyzeBatch(files);
      const okItems = (d.items || []).filter((x) => x.ok !== false && x.uploadId);
      const badItems = (d.items || []).filter((x) => x.ok === false);
      if (badItems.length) {
        setError(badItems.map((b) => (b.name || 'file') + ': ' + b.error).join(' · '));
      }
      if (okItems.length) {
        // default every item to its recommended preset
        const sel = {};
        for (const it of okItems) sel[it.uploadId] = (it.recommendation && it.recommendation.presetId) || 'remux';
        setItems((prev) => {
          const merged = [...prev];
          for (const it of okItems) merged.push(it);
          return merged;
        });
        setPresetSel((prev) => ({ ...prev, ...sel }));
      }
      setPhase('ready');
    } catch (e) {
      setError(e.message);
      setPhase(items.length ? 'ready' : 'idle');
    }
  }

  function setItemPreset(uploadId, presetId) {
    setPresetSel((p) => ({ ...p, [uploadId]: presetId }));
  }

  function applyPresetToAll(presetId) {
    setApplyAll(presetId);
    setPresetSel((p) => {
      const next = {};
      for (const it of items) next[it.uploadId] = presetId;
      return next;
    });
  }

  function removeItem(uploadId) {
    setItems((prev) => prev.filter((it) => it.uploadId !== uploadId));
    setPresetSel((p) => {
      const n = { ...p };
      delete n[uploadId];
      return n;
    });
  }

  async function startAll() {
    setError(null);
    let hadError = false;
    for (const it of items) {
      const presetId = presetSel[it.uploadId] || 'remux';
      const cleanAdv = { ...DEFAULT_ADV };
      try {
        await api.optimize(it.uploadId, presetId, cleanAdv);
      } catch (e) {
        hadError = true;
        setError((prev) => (prev ? prev + ' · ' : '') + it.file.name + ': ' + e.message);
      }
    }
    if (!hadError) setError(null);
    // keep analyzed cards visible; queue panel below shows live progress
  }

  function resetAll() {
    setItems([]); setPresetSel({}); setApplyAll(''); setError(null); setPhase('idle');
  }

  const queueBusy = queue.some((j) => j.state === 'waiting' || j.state === 'processing');

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>Optimizer</h1>
          <p className="page-sub">Lossless remux by default · NVENC GPU encode when available · batch queue</p>
        </div>
        {items.length > 0 && <button className="btn ghost" onClick={resetAll}>↵ Clear list</button>}
      </header>

      <ErrorBar>{error}</ErrorBar>

      {(phase === 'idle' || phase === 'ready') && (
        <DropZone
          onFiles={onFiles}
          busy={phase === 'analyzing'}
          multiple={true}
        />
      )}

      {phase === 'analyzing' && (
        <div className="card center-card"><div className="spinner" /> Probing with FFprobe…</div>
      )}

      {/* GPU status strip */}
      {gpu && (
        <GpuStrip gpu={gpu} stats={gpuStats} />
      )}

      {/* Batch source list */}
      {items.length > 0 && (
        <Card
          title={'Sources (' + items.length + ')'}
          right={
            <div className="btn-row" style={{ marginTop: 0 }}>
              <select
                className="btn tiny-select"
                value={applyAll}
                onChange={(e) => { if (e.target.value) applyPresetToAll(e.target.value); }}
              >
                <option value="">Apply preset to all…</option>
                {presets.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
              <button className="btn primary" disabled={queueBusy} onClick={startAll}>⚡ Queue all</button>
            </div>
          }
        >
          <div className="batch-list">
            {items.map((it) => (
              <BatchItem
                key={it.uploadId}
                item={it}
                presets={presets}
                selected={presetSel[it.uploadId] || 'remux'}
                onSelect={(pid) => setItemPreset(it.uploadId, pid)}
                onRemove={() => removeItem(it.uploadId)}
              />
            ))}
          </div>
        </Card>
      )}

      {/* Queue */}
      {queue.length > 0 && (
        <Card
          title={'Queue (' + queue.filter((j) => j.state === 'waiting').length + ' waiting · ' + queue.filter((j) => j.state === 'processing').length + ' processing)'}
          right={
            <button className="btn ghost tiny" onClick={() => api.queueClearFinished().catch(() => {})}>Clear finished</button>
          }
        >
          <div className="queue-list">
            {queue.map((j) => (
              <QueueRow
                key={j.id}
                job={j}
                logOpen={expandedLog === j.id}
                onToggleLog={() => setExpandedLog(expandedLog === j.id ? null : j.id)}
              />
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

function GpuStrip({ gpu, stats }) {
  if (!gpu.available) {
    return (
      <div className="gpu-strip off">
        <Badge kind="warn">CPU ONLY</Badge>
        <span className="muted small">{gpu.reason || 'No NVIDIA GPU / NVENC detected — CPU encode (libx264/libx265) will be used.'}</span>
      </div>
    );
  }
  const encoders = [gpu.nvenc.h264 && 'H.264', gpu.nvenc.hevc && 'H.265', gpu.nvenc.av1 && 'AV1'].filter(Boolean).join(' · ');
  return (
    <div className="gpu-strip on">
      <Badge kind="good">NVENC READY</Badge>
      <span className="mono small">{gpu.name}</span>
      <span className="muted small">{encoders || 'no encoders'}</span>
      {stats && (
        <span className="gpu-stats mono small">
          GPU {stats.gpuUtil != null ? stats.gpuUtil + '%' : '—'} · VRAM {stats.vramUsedMb != null ? (stats.vramUsedMb / 1024).toFixed(1) + '/' + (stats.vramTotalMb / 1024).toFixed(1) + ' GB' : '—'}
          {stats.encSessions ? ' · NVENC sessions ' + stats.encSessions : ''}
          {stats.tempC != null ? ' · ' + stats.tempC + '°C' : ''}
        </span>
      )}
    </div>
  );
}

function BatchItem({ item, presets, selected, onSelect, onRemove }) {
  const rec = item.recommendation;
  const v = item.video, a = item.audio;
  return (
    <div className="batch-item">
      <div className="batch-item-head">
        <div className="batch-item-name mono" title={item.file.name}>{item.file.name}</div>
        <Badge kind={(rec && rec.presetId === 'remux') ? 'good' : 'info'}>
          {(rec && rec.presetId && (presets.find((p) => p.id === rec.presetId) || {}).name) || '—'}
        </Badge>
        <button className="btn ghost tiny" onClick={onRemove} title="Remove from list">✕</button>
      </div>
      <div className="batch-item-specs muted small mono">
        {[v.resolution, (v.fps || '?') + ' fps', v.codec, v.pixFmt, a ? a.codec : 'no audio', item.file.size && item.file.size.human, v.isHdr ? 'HDR' : null].filter(Boolean).join(' · ')}
      </div>
      {rec && (
        <div className="rec-line">
          <span className="rec-tag">Recommended Export</span>
          <span className="muted small">{rec.reasons.join(' · ')}</span>
          <button className="btn ghost tiny" onClick={() => onSelect(rec.presetId)}>use</button>
        </div>
      )}
      <select
        className="batch-preset-select"
        value={selected}
        onChange={(e) => onSelect(e.target.value)}
      >
        {presets.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
      </select>
    </div>
  );
}

function QueueRow({ job, logOpen, onToggleLog }) {
  const st = job.state;
  const stLabel = { waiting: 'Waiting', processing: 'Processing', completed: 'Completed', failed: 'Failed', cancelled: 'Cancelled' }[st] || st;
  const stKind = { waiting: 'info', processing: 'info', completed: 'good', failed: 'bad', cancelled: 'warn' }[st] || 'info';
  const p = job.progress;
  return (
    <div className={'queue-row st-' + st}>
      <div className="queue-row-main">
        <Badge kind={stKind}>{stLabel}</Badge>
        {job.accel && <Badge kind={job.accel === 'LOSSLESS REMUX' ? 'good' : job.accel === 'GPU ENCODE' ? 'info' : 'warn'}>{job.accel}</Badge>}
        <div className="queue-row-name mono" title={job.sourceName}>{job.sourceName}</div>
        <div className="queue-row-sub muted small">{job.presetName}</div>
      </div>

      {st === 'processing' && p && (
        <div className="queue-row-progress">
          <div className="progress-track slim"><div className="progress-fill" style={{ width: (p.pct != null ? Math.min(100, p.pct) : 4) + '%' }} /></div>
          <div className="progress-stats mono small">
            <span>{p.pct != null ? p.pct.toFixed(0) + '%' : '…'}</span>
            <span>⏱ {fmtMs(p.elapsedMs)}</span>
            <span>⏳ {p.etaSec != null ? fmtMs(p.etaSec * 1000) : '—'}</span>
            <span>{p.fps ? p.fps + ' fps' : ''}</span>
            <span>{p.speed ? '×' + p.speed : ''}</span>
            <span>{p.sizeBytes ? fmtBytes(p.sizeBytes) : ''}</span>
          </div>
        </div>
      )}
      {st === 'processing' && !p && <div className="queue-row-progress muted small">starting ffmpeg…</div>}

      <div className="queue-row-actions">
        {(st === 'processing' || st === 'waiting') && (
          <button className="btn ghost tiny" onClick={() => api.queueCancel(job.id).catch(() => {})}>Cancel</button>
        )}
        {(st === 'failed' || st === 'cancelled') && (
          <button className="btn ghost tiny" onClick={() => api.queueRetry(job.id).catch(() => {})}>Retry</button>
        )}
        {['completed', 'failed', 'cancelled'].includes(st) && (
          <button className="btn ghost tiny" onClick={() => api.queueRemove(job.id).catch(() => {})}>Remove</button>
        )}
        {job.logLines && job.logLines.length > 0 && (
          <button className="btn ghost tiny" onClick={onToggleLog}>{logOpen ? '▾' : '▸'} log</button>
        )}
        {st === 'completed' && job.result && job.result.output && (
          <button className="btn ghost tiny" onClick={() => api.openFolder(job.outDir || job.result.output.dir)}>📂</button>
        )}
      </div>

      {job.error && <div className="queue-row-error errorbar slim">⚠ {job.error}</div>}
      {logOpen && <LogViewer lines={job.logLines || []} defaultOpen={true} />}
    </div>
  );
}

function fmtMs(ms) {
  if (ms == null || !isFinite(ms)) return '—';
  const s = Math.round(ms / 1000);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return (h ? h + 'h ' : '') + (m ? m + 'm ' : '') + sec + 's';
}
