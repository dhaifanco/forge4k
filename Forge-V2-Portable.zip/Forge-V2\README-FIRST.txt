================================================================
   FORGE V2  -  Local Video Optimizer   (portable Windows edition)
================================================================

WHAT THIS IS
A 100% local TikTok / Reels / Shorts video optimizer.
FFprobe inspection + lossless remux + optional smart re-encode.
Nothing leaves your PC - no cloud, no accounts, no uploads.


----------------------------------------------------------------
QUICK START (3 steps)
----------------------------------------------------------------
1. Install Node.js LTS from  https://nodejs.org   (if not installed)
   - Download "Node.js (LTS)" for Windows, run the installer.
   - On the "Tools for Native Modules" step, ticking the box is
     NOT needed for Forge.

2. Double-click  START-FORGE.bat
   - First run downloads app libraries (~1 minute) and builds the
     interface (~20 seconds). Subsequent runs skip these steps.
   - A console window opens - keep it open while using Forge.

3. Your browser opens automatically at  http://127.0.0.1:5177


----------------------------------------------------------------
FFMPEG (needed to actually optimize videos)
----------------------------------------------------------------
Forge auto-detects FFmpeg/FFprobe on your PATH and common
install locations. On a fresh PC they are usually NOT present.

Two ways to get FFmpeg:

  EASY (inside Forge, no admin rights)
    Open the app -> Settings tab -> "Auto-install FFmpeg (Windows)".
    Forge downloads the gyan.dev essentials build into
    %LOCALAPPDATA%\ffmpeg and registers it automatically.

  MANUAL (if you already have a build)
    Put ffmpeg.exe + ffprobe.exe somewhere, then in Settings
    set the "ffmpeg path" and "ffprobe path" to those .exe files.


----------------------------------------------------------------
GPU ACCELERATION (optional, automatic)
----------------------------------------------------------------
- Forge auto-detects NVIDIA / NVENC. If your FFmpeg build has
  NVENC and the GPU can open an encoder, GPU (h264_nvenc /
  hevc_nvenc) is used automatically.
- If there is no supported NVIDIA GPU, or NVENC cannot open a
  session, Forge automatically falls back to CPU (libx264 /
  libx265). Nothing to configure.
- Toggle it any time in Settings -> "Prefer GPU encoding".


----------------------------------------------------------------
WHERE FILES GO (created fresh on this PC)
----------------------------------------------------------------
This package ships with NO personal data, NO history, NO temp.
Each PC creates its own folders:

  App folder\             - the program (don't edit)
  App folder\dist\        - built interface (auto-created on first run)
  App folder\node_modules\- libraries (auto-installed on first run)
  App folder\data\        - fresh local settings + history for THIS PC
  %LOCALAPPDATA%\Forge\temp\ - scratch / work files (outside OneDrive)
  <Videos>\Forge Optimizer\  - where optimized videos are written

You can change the output and temp folders in Settings.


----------------------------------------------------------------
TO STOP FORGE
----------------------------------------------------------------
Close the console window, or press Ctrl+C in it.
Forge runs only while that window is open.


----------------------------------------------------------------
RE-SHARING / MOVING TO ANOTHER PC
----------------------------------------------------------------
Copy the whole Forge-V2 folder (or the .zip) to the new PC.
You do NOT need to include node_modules or dist - START-FORGE
rebuilds them. Copying Forge-V2-Portable.zip is enough.


----------------------------------------------------------------
IF SOMETHING GOES WRONG
----------------------------------------------------------------
- "Node.js was not found"   -> install Node.js LTS, then re-run.
- "EADDRINUSE ... 5177"     -> another copy of Forge is already
  running. Close it and run START-FORGE again.
- npm install fails         -> check the internet connection,
  then run START-FORGE again (it retries the install).
- FFmpeg not found          -> Settings -> Auto-install FFmpeg.

================================================================
