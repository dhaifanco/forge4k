# Forge — Local Video Optimizer

A 100% local TikTok / Reels / Shorts video optimizer. FFprobe inspection, lossless
container remux by default, optional smart re-encode. **No cloud, no accounts, no
uploads — videos never leave your PC.**

## Run it

```
npm install
npm run dev
```

Then open **http://localhost:5178**

Production-style single-server mode (serves the built frontend from the API port):

```
npm run preview      # build + serve on http://127.0.0.1:5177
```

## FFmpeg

Detected automatically: your PATH, common install locations, or paths saved in
Settings. If it's missing, Settings → **Auto-install FFmpeg (Windows)** downloads
the gyan.dev essentials build into `%LOCALAPPDATA%\ffmpeg` (no admin rights) and
registers it. You can also set custom `ffmpeg.exe` / `ffprobe.exe` paths in Settings.

## What "optimization" means here (honest version)

No tool can bypass platform transcoding. What actually maximizes upload quality is
feeding platforms a clean, standard, high-bitrate master:

- **Lossless Remux (default):** stream copy (`-c copy`) — zero quality loss. Rebuilds
  the container: `+faststart` (moov atom up front), stripped metadata, data/timecode
  streams dropped, chapters removed, MP4 container.
- **Smart presets** (TikTok Max / 1080p60 / 4K60 / 4K120 / Reels / Shorts): stream
  copy when the source already matches the target; otherwise re-encode only what's
  needed (e.g. HEVC→H.264, 10-bit→8-bit, downscale, fps cap). Audio is copied when
  already AAC.

## Presets

Lossless Remux · TikTok Maximum Quality · TikTok 1080p60 · TikTok 4K60 ·
TikTok 4K120 · Instagram Reels · YouTube Shorts

## Pages

- **Optimizer** — drop file → health check → preset → advanced options → before/after specs
- **Video Analyzer** — full FFprobe inspection (codecs, fps, bitrate, color, metadata, compatibility)
- **History** — local processing records in `data/history.json` (nothing else is stored)
- **Settings** — FFmpeg detection/install, output folder, history limit

## Privacy

Everything runs on `127.0.0.1`. The only network calls the app itself can make is the
optional FFmpeg download from gyan.dev (Settings → auto-install). Analyzed files are
staged in `data/uploads/` and deleted after successful optimization.

## Stack

Node.js + Express API (port 5177) · React + Vite frontend (port 5178, proxied) ·
FFmpeg/FFprobe (any recent build) · Windows-first, no build tools required beyond Node.
