import React from 'react';
import { api, fmtBytes, fmtDur } from '../api';
import { Card, Badge, ErrorBar } from '../ui.jsx';

export default function History() {
  const [items, setItems] = React.useState(null);
  const [error, setError] = React.useState(null);
  const [expanded, setExpanded] = React.useState(null);

  function load() {
    api.history().then((d) => setItems(d.items)).catch((e) => setError(e.message));
  }
  React.useEffect(load, []);

  async function del(id) {
    await api.deleteHistory(id).catch(() => {});
    load();
  }
  async function clear() {
    if (!confirm('Delete all local processing history? Output files on disk are not touched.')) return;
    await api.clearHistory().catch(() => {});
    load();
  }

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>History</h1>
          <p className="page-sub">Local processing records only — stored in data/history.json on this PC.</p>
        </div>
        {items && items.length > 0 && <button className="btn ghost" onClick={clear}>Clear all</button>}
      </header>

      <ErrorBar>{error}</ErrorBar>

      {items == null && <div className="card center-card"><div className="spinner" /> Loading…</div>}

      {items && items.length === 0 && (
        <div className="card center-card muted">No jobs yet. Optimize a video and it will show up here.</div>
      )}

      {items && items.map((r) => (
        <div key={r.id} className={'hist-card card status-' + r.status}>
          <div className="hist-top" onClick={() => setExpanded(expanded === r.id ? null : r.id)}>
            <Badge kind={r.status === 'done' ? (r.mode === 'lossless remux' ? 'good' : 'info') : 'bad'}>
              {r.status === 'done' ? r.mode : r.status}
            </Badge>
            <div className="hist-main">
              <div className="hist-name mono">{r.source ? r.source.name : r.id}</div>
              <div className="hist-sub">
                {r.presetName} · {fmtDur((r.durationMs || 0) / 1000)} · {new Date(r.startedAt).toLocaleString()}
                {r.source && r.source.size && r.output && r.output.size ? ' · ' + r.source.size.human + ' → ' + r.output.size.human : ''}
              </div>
            </div>
            <div className="hist-actions">
              {r.output && r.output.dir && (
                <button className="btn ghost tiny" onClick={(e) => { e.stopPropagation(); api.openFolder(r.output.dir); }}>📂</button>
              )}
              <button className="btn ghost tiny" onClick={(e) => { e.stopPropagation(); del(r.id); }}>✕</button>
            </div>
          </div>

          {r.error && <div className="errorbar slim">⚠ {r.error}</div>}

          {expanded === r.id && (
            <div className="hist-detail">
              <div className="muted small">{r.reason}</div>
              <pre className="cmd">{r.command}</pre>
              {r.beforeSpecs && r.afterSpecs && (
                <table className="cmp-table">
                  <thead><tr><th></th><th>Source</th><th>Output</th></tr></thead>
                  <tbody>
                    <tr><td className="cmp-label">Container</td><td className="mono">{r.beforeSpecs.format.container}</td><td className="mono">{r.afterSpecs.format.container}</td></tr>
                    <tr><td className="cmp-label">Video</td><td className="mono">{[r.beforeSpecs.video.codec, r.beforeSpecs.video.resolution, r.beforeSpecs.video.fps].filter(Boolean).join(' · ')}</td><td className="mono">{r.afterSpecs ? [r.afterSpecs.video.codec, r.afterSpecs.video.resolution, r.afterSpecs.video.fps].filter(Boolean).join(' · ') : '—'}</td></tr>
                    <tr><td className="cmp-label">Size</td><td className="mono">{r.beforeSpecs.file.size && r.beforeSpecs.file.size.human}</td><td className="mono">{r.afterSpecs && r.afterSpecs.file.size && r.afterSpecs.file.size.human}</td></tr>
                  </tbody>
                </table>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
