import React from 'react';

export function Card({ title, right, children, className = '' }) {
  return (
    <div className={'card ' + className}>
      {(title || right) && (
        <div className="card-head">
          <h3>{title}</h3>
          {right}
        </div>
      )}
      <div className="card-body">{children}</div>
    </div>
  );
}

export function Spec({ label, value, mono = true, warn = false, good = false }) {
  return (
    <div className="spec">
      <span className="spec-label">{label}</span>
      <span className={'spec-value' + (mono ? ' mono' : '') + (warn ? ' warn-text' : '') + (good ? ' good-text' : '')}>
        {value == null || value === '' ? '—' : value}
      </span>
    </div>
  );
}

export function Badge({ kind = 'info', children }) {
  return <span className={'badge badge-' + kind}>{children}</span>;
}

export function Dot({ ok, warn }) {
  return <span className={'dot ' + (ok ? 'dot-ok' : warn ? 'dot-warn' : 'dot-bad')} />;
}

// V2: multiple={true} enables multi-select + multi-drop for the batch queue.
export function DropZone({ onFile, onFiles, busy, multiple = false, label, sub }) {
  const [over, setOver] = React.useState(false);
  const inputRef = React.useRef(null);
  const mainLabel = label || (multiple ? 'Drop MP4 / MOV files here' : 'Drop MP4 / MOV here');
  const mainSub = sub || (multiple ? 'multiple files OK — or click to browse' : 'or click to browse — the file never leaves this PC');
  const accept = multiple ? 'video/mp4,video/quicktime,.mp4,.mov,.m4v' : 'video/mp4,video/quicktime,.mp4,.mov,.m4v';
  return (
    <div
      className={'dropzone' + (over ? ' over' : '') + (busy ? ' busy' : '')}
      onClick={() => !busy && inputRef.current && inputRef.current.click()}
      onDragOver={(e) => { e.preventDefault(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.preventDefault(); setOver(false);
        if (busy) return;
        const files = Array.from((e.dataTransfer.files && e.dataTransfer.files) || []);
        if (!files.length) return;
        if (multiple) onFiles && onFiles(files);
        else if (files[0]) onFile && onFile(files[0]);
      }}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        style={{ display: 'none' }}
        onChange={(e) => {
          const files = Array.from((e.target.files && e.target.files) || []);
          if (files.length) {
            if (multiple) onFiles && onFiles(files);
            else onFile && onFile(files[0]);
          }
          e.target.value = '';
        }}
      />
      <div className="dz-icon">⬇</div>
      <div className="dz-label">{busy ? 'Reading file…' : mainLabel}</div>
      <div className="dz-sub">{mainSub}</div>
    </div>
  );
}

export function ErrorBar({ children }) {
  if (!children) return null;
  return <div className="errorbar">⚠ {children}</div>;
}

// V2: collapsible FFmpeg log with copy-to-clipboard + download.
export function LogViewer({ lines = [], defaultOpen = false, title = 'FFmpeg log' }) {
  const [open, setOpen] = React.useState(defaultOpen);
  const boxRef = React.useRef(null);
  const text = (lines || []).join('\n');
  return (
    <div className="logviewer">
      <button className="btn ghost tiny" onClick={() => setOpen(!open)}>
        {open ? '▾' : '▸'} {title} ({lines.length} lines)
      </button>
      {open && (
        <>
          <div className="log-actions">
            <button className="btn ghost tiny" onClick={() => navigator.clipboard && navigator.clipboard.writeText(text)}>Copy</button>
            <button className="btn ghost tiny" onClick={() => {
              const blob = new Blob([text], { type: 'text/plain' });
              const a = document.createElement('a');
              a.href = URL.createObjectURL(blob);
              a.download = 'forge-ffmpeg-log.txt';
              a.click();
              URL.revokeObjectURL(a.href);
            }}>Download</button>
          </div>
          <pre className="log-box" ref={boxRef}>{text || '(no log output)'}</pre>
        </>
      )}
    </div>
  );
}

// V2: progress readout — percentage, elapsed, ETA, fps, speed, output size.
export function ProgressPanel({ progress, accel, onCancel, extra }) {
  const pct = progress && progress.pct != null ? progress.pct : null;
  return (
    <div className="progress-panel">
      <div className="progress-top">
        {accel && <Badge kind={accel === 'LOSSLESS REMUX' ? 'good' : accel === 'GPU ENCODE' ? 'info' : 'warn'}>{accel}</Badge>}
        <div className="progress-num mono">{pct != null ? pct.toFixed(1) + '%' : 'working…'}</div>
      </div>
      <div className="progress-track">
        <div className="progress-fill" style={{ width: (pct != null ? Math.min(100, pct) : 4) + '%' }} />
      </div>
      <div className="progress-stats mono small">
        <span>⏱ {fmtElapsed(progress && progress.elapsedMs)}</span>
        <span>⏳ {progress && progress.etaSec != null ? fmtElapsed(progress.etaSec * 1000) : '—'}</span>
        <span>{progress && progress.fps ? progress.fps + ' fps' : 'fps —'}</span>
        <span>{progress && progress.speed ? '×' + progress.speed : 'speed —'}</span>
        <span>{progress && progress.sizeBytes ? fmtBytesCompat(progress.sizeBytes) : '—'}</span>
        {progress && progress.bitrate ? <span>{progress.bitrate}</span> : null}
      </div>
      {extra}
      {onCancel && <div className="progress-actions"><button className="btn danger ghost" onClick={onCancel}>Cancel</button></div>}
    </div>
  );
}

function fmtElapsed(ms) {
  if (ms == null || !isFinite(ms)) return '—';
  const s = Math.round(ms / 1000);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return (h ? h + 'h ' : '') + (m ? m + 'm ' : '') + sec + 's';
}

function fmtBytesCompat(b) {
  if (b == null || isNaN(b)) return '—';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0; let v = Number(b);
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return (i === 0 ? v : v.toFixed(v < 10 ? 2 : 1)) + ' ' + units[i];
}
