@echo off
title Forge V2 - Local Video Optimizer
cd /d "%~dp0"

echo ==================================================
echo    FORGE V2  -  Local Video Optimizer
echo ==================================================
echo.

rem ---- 1. Check Node.js ---------------------------------------------
where node >nul 2>nul
if errorlevel 1 (
    echo [X] Node.js was not found on this PC.
    echo.
    echo     Please install the Node.js LTS version first:
    echo     https://nodejs.org
    echo     Then run START-FORGE again.
    echo.
    pause
    exit /b 1
)

for /f "delims=" %%v in ('node --version') do set "NODE_VERSION=%%v"
node -e "if(parseInt(process.versions.node.split('.')[0])<18)process.exit(1)" >nul 2>nul
if errorlevel 1 (
    echo [X] Node.js %NODE_VERSION% is too old - version 18 or newer is required.
    echo     Please install the current LTS from https://nodejs.org
    echo.
    pause
    exit /b 1
)
echo [OK] Node.js %NODE_VERSION% found.

rem ---- 2. Install dependencies on first run -------------------------
if not exist "node_modules\express" (
    echo.
    echo [..] Installing app libraries - internet needed, one time only...
    call npm install --no-audit --no-fund
    if errorlevel 1 (
        echo.
        echo [X] npm install failed. Check your internet connection,
        echo     then run START-FORGE again.
        echo.
        pause
        exit /b 1
    )
    echo [OK] Libraries installed.
)

rem ---- 3. Build the interface on first run ---------------------------
if not exist "dist\index.html" (
    echo.
    echo [..] Building the interface - one time only...
    call npm run build
    if errorlevel 1 (
        echo.
        echo [X] Build failed. Delete the folder, unzip again and retry.
        echo.
        pause
        exit /b 1
    )
    echo [OK] Interface built.
)

rem ---- 4. Start Forge and open the browser --------------------------
if not defined PORT set "PORT=5177"
echo.
echo [OK] Starting Forge...
echo      Address:  http://127.0.0.1:%PORT%
echo      Keep this window open while using Forge.
echo      To stop Forge: close this window or press Ctrl+C.
echo.

rem Open the browser automatically once the server answers.
start "" /b node -e "const h=require('http'),c=require('child_process');const p=process.env.PORT||5177;let n=0;(function f(){h.get('http://127.0.0.1:'+p+'/api/health',r=>{c.exec('cmd /c start http://127.0.0.1:'+p);process.exit(0)}).on('error',()=>{if(++n<300)setTimeout(f,300)})})()"

node server\index.js

echo.
echo Forge has stopped.
pause
